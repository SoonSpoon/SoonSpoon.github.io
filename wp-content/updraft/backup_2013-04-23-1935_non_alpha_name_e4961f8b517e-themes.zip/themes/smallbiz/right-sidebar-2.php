	</div>
<div id="sidebar">
<ul>
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar Optional 2') ) : else : ?>
<?php endif; ?>
</ul>
</div>