	</div>
<div id="sidebar">
<ul>
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar Optional 1') ) : else : ?>
<?php endif; ?>
</ul>
</div>