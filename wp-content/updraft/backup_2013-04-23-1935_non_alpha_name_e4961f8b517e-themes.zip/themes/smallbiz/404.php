<?php
include("pre-header.inc.php");
?><?php get_header(); ?>
		<h2 class="center">Sorry this page is not available - Not Found</h2>
<?php get_sidebar(); ?>
<?php get_footer(); ?>