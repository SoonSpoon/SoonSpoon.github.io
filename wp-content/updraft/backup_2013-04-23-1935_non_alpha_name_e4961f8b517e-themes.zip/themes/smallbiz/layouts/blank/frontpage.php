<?php
/**
 * Blank - No Sidebar front page theme.
 *
 * @package WordPress
 * @subpackage Expand2Web SmallBiz
 * @since Expand2Web SmallBiz 3.3
 */
 
  $hideSidebar = true;
?>
	<div id="home-noside-text">  
	    <?php echo do_shortcode(biz_option('smallbiz_noside_text'))?>
    </div>
    
    </div>