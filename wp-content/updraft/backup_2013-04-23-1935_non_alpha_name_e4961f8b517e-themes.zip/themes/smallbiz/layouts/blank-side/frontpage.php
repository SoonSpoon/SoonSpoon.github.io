<?php
/**
 * Blank front page theme.
 *
 * @package WordPress
 * @subpackage Expand2Web SmallBiz
 * @since Expand2Web SmallBiz 3.3
 */
?>
    <div id="homewrap">
	<div id="homeblanktext">  
	    <?php echo do_shortcode(biz_option('smallbiz_mainblank_text'))?>
    </div>
    </div>