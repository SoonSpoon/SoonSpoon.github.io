			<p id="copyright"><?php esc_html_e('Designed by','InStyle'); ?> <a href="http://www.elegantthemes.com">Elegant WordPress Themes</a> | <?php esc_html_e('Powered by', 'InStyle'); ?> <a href="http://www.wordpress.org">WordPress</a></p>
		</div> <!-- end #container-->
	</div> <!-- end #background -->	
	
	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>	
	
</body>
</html>