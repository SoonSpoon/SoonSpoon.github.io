<?php 
	/*
 		MAIN CLASS FOR BACKUPING DATABASE
		
		THINGS BACKUP CLASS NEEDS:
		
			- VERIFY DATABASE
			- VERIFY FOLDER PERMISSIONS
	*/
	
class permissionCheck {
	
	// DO CHECKS BEFORE RUNNING THE SCRIPT
	public function __contruct(){
		
		}
		
	// TEST 
	public function test() {
		print 'TEST GOOD';
		}
		
	
	}
?>