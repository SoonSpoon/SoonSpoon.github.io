<?php 
	/*
 		MAIN CLASS FOR BACKUPING DATABASE
		
		THINGS BACKUP CLASS NEEDS:
			- PUSH BACKUP TO FTP SERVER
			- POSSIBLE API PING TO DOWNLOAD BACKUP
	*/
	
class ccbFTP {
	
	// DO CHECKS BEFORE RUNNING THE SCRIPT
	public function __contruct(){
		
		}
		
	// TEST 
	public function test() {
		print 'TEST GOOD';
		}
		
	
	}
?>