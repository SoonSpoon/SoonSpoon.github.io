/*
 * Google Maps - Widget
 * (c) Daniel Martyn, 2013 - http://dan.evenweb.com
 */

jQuery(function($) {
    $('a.gmbdm-thumbnail-map').click(function() {
      dialog = $($(this).attr('href'));
      map_width = dialog.attr('data-map-width');
      map_height = dialog.attr('data-map-height');
      map_url = dialog.attr('data-map-iframe-url');
      map_title = dialog.attr('title');
      map_skin = dialog.attr('data-map-skin');
      
      var content = $(dialog.html());
      content.filter('.gmbdm-map').html('<iframe width="' + map_width + 'px" height="' + map_height + 'px" src="' + map_url + '"></iframe>');

      $.thebox( { 'wrapCSS': map_skin, 'type': 'html', 'content': content, 'title': map_title, 'autoSize': true, 'minWidth': map_width, 'minHeight': map_height } );
      
      return false;
    });
}); // onload