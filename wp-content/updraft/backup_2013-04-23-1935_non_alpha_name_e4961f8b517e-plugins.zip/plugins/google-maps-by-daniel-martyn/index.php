<?php
  // Silence is golden.
?>