=== Google Map - Widget ===
Contributors: Danielmartyn
Donate link: http://dan.evenweb.com
Tags: google map, google maps, map, maps, direction, location, address, info, window, google, widget, plugin, admin, sidebar, images, image, ajax, lightbox, photo, photos, shortcode, javascript, jquery, gallery, content, media, page, post, contact, shop, company, information, info, comments, links, google, twitter, website, itinerary, marker, gpx, kml, geo, short code
License: GPLv2 or later
Requires at least: 3.2
Tested up to: 3.5
Stable tag: 1.0

No API Key is required. Displays Fully Customizable Google Map via Widget. Small/Large Map + advanced features including Lightbox.

== Description ==

No API Key is required. Displays Fully Customizable Google Map via Widget. Small/Large Map + advanced features including Lightbox.

**Lightbox map options**

* map size - width and height
* map type - satellite,road map or hybrid
* zoom level
* skin
* show or hide address bubble
* show or hide map title
* header text
* footer text

**Thumbnail options**

* map size - width and height
* map type - satellite, road, map or hybrid
* color
* size
* zoom level

**Widget options**

* title
* address

If you need support for the plugin please visit donate link and contact me.

== Installation ==

1. From WP admin - Plugins - Add New
2. Search "Google Maps by Daniel Martyn" under search and hit Enter
3. Plugin will show up in the TOP on the list, click "Install Now"

To upload manually;

1. Download the plugin from Wordpress Repository.
2. Unzip it and upload to yoursite.com/wp-content/plugin/
3. From WP admin - Plugins and click "Activate" next to the plugin
4. Configure plugin under Appearance - Widgets

== Frequently Asked Questions ==

= Who is this plugin for? =

For just about anyone who needs a google map displayed on their site.

= It's not working, why? =

Does your theme have wp_footer() function in the footer?

== Changelog ==

= 1.0 =
* 2013/22/03
* Initial release

== Upgrade Notice ==

= 1.0 =
Initial release