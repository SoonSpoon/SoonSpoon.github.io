<?php
include(dirname(__FILE__) . "/router.php");
