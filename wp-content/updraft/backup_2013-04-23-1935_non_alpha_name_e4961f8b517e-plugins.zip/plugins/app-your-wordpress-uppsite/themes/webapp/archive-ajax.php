<?php
uppsite_posts_list('wp_get_archives');
