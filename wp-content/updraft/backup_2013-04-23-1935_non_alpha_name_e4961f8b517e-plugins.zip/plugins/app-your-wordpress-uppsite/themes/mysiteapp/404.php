<?php
get_template_part('header');
?><error><![CDATA[Sorry, this page does not exist]]></error>
<?php get_template_part('footer'); ?>
